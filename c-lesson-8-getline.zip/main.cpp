/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/*#include <iostream>
#include <string>
using namespace std;
int main ()
{
    string x="20";
    string y="23";
    string z=x+y;
    cout<<z;
    return 0;
}*/
/*#include <iostream>
using namespace std;
int main ()
{
    int x,y,z;
    x=101;
    y=1;
    z=x-y;
    cout<<z;
    return 0;
}*/
/*#include <iostream>
#include <string>
using namespace std;
int main ()
{
    string x="Today is monday and ";
    string y="this is lesson 8 of c++";
    string z=x+y;
    cout<<z;
    return 0;
}*/
/*#include <iostream>
#include <string>
int main ()
{
    std::string x="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    std::cout<<"There are "<<x.length()<<" letters in the alphebet";
    return 0;
}*/
/*#include <iostream>
#include <string>
int main ()
{
    std::string x="extraordinary";
    std::cout<<"There are "<<x.size()<<" letters in the word extraordinary";
    return 0;
}*/
/*#include <iostream>
#include <string>
int main()
{
    std::string x="C++ is a cross-platform language that can be used to create high-performance applications.";
    std::cout<<x[62];
    return 0;
}*/
/*#include <iostream>
#include <string>
int main ()
{
    std::string x="C++ was designed with systems programming and embedded, resource-constrained software and large systems in mind, with performance, efficiency, and flexibility of use as its design highlights.[14] C++ has also been found useful in many other contexts, with key strengths being software infrastructure and resource-constrained applications,[14] including desktop applications, video games, servers (e.g. e-commerce, web search, or databases), and performance-critical applications";
    std::cout<<x[150];
    return 0;
}*/
/*#include <iostream>
#include <string>
int main()
{
    std::string x="king";
    x[0]='w';
    std::cout<<x;
    return 0;
}*/
#include <iostream>
#include <string>
int main()
{
    std::string x;
    std::cout<<"Type your full name";
    getline(std::cin,x);
    std::cout<<" My full name is "<<x;
    return 0;
}



































