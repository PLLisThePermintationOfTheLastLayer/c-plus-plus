
/*#include <iostream>
using namespace std;
int main()
{
    int age;
    cout<<"Type your age:";
    cin>>age;
    if(age>=18)
    {
        cout<<"Eligible for voting";
    }
    return 0;
}*/
/*#include <iostream>
using namespace std;
int main()
{
    int age;
    cout<<"Type your age:";
    cin>>age;
    if(age>=18)
    {
        cout<<"Eligible for voting";
    }
    else
    {
        cout<<"Not eligible";
    }
    return 0;
}*/
/*#include <iostream>
using namespace std;
int main()
{
    int time;
    if(time<24)
    {
    cout<<"Good morning";
    }
    else if(time<19)
    {
        cout<<"good afternoon";
    }
    else
    {
        cout<<"Good evening";
    }
    return 0;
}*/
/*#include <iostream>
using namespace std;
int main()
{
    int age;
    cout<<"Type your age";
    cin>>age;
    if(age<=12)
    {
        cout<<"You are a child";
    }
    /*else if(age>20
    {
        cout<<"You are a adult";
    }
    else if(age>123)
    {
        cout<<"You are dead";
    }
    else{
        cout<<"You are a teen";
    }
    return 0;
}*/
/*#include <iostream>
using namespace std;
int main()
{
    int day=3;
    switch (day)
    {
        case 1:
        cout<<"Monday";
        break;
        case 2:
        cout<<"Tuesday";
        break;
        case 3:
        cout<<"Wednesday";
        break;
        case 4:
        cout<<"Thursday";
        break;
        case 5:
        cout<<"Friday";
        break;
        case 6:
        cout<<"Saturday";
        break;
        case 7:
        cout<<"Sunday";
        break;
    }
    return 0;
}*/
/*#include <iostream>
using namespace std;
int main()
{
    int months=6;
    switch (months)
    {
        case 1:
        cout<<"January";
        break;
        case 2:
        cout<<"Febuary";
        break;
        case 3:
        cout<<"March";
        break;
        case 4:
        cout<<"April";
        break;
        case 5:
        cout<<"May";
        break;
        case 6:
        cout<<"June";
        break;
        case 7:
        cout<<"July";
        break;
        case 8:
        cout<<"August";
        break;
        case 9:
        cout<<"September";
        break;
        case 10:
        cout<<"October";
        break;
        case 11:
        cout<<"November";
        break;
        case 12:
        cout<<"December";
        break;
    }
    return 0;
}*/









