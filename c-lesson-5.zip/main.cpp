/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/*#include <iostream>
int main()
{
    int a=10;
    int b=20;
    std::cout<<a+b;
    return 0;
}*/
/*#include <iostream>
int main()
{
    int a=10;
    int b=20;
    std::cout<<a+b;
    return 0;
    //addition
}*/
/*#include <iostream>
int main()
{
    int a=10;
    int b=20;
    std::cout<<a-b;
    return 0;
    //subtraction
}*/
/*#include <iostream>
int main()
{
    int a=10;
    int b=20;
    std::cout<<a*b;
    return 0;
    //multiplication
}*/
/*#include <iostream>
int main()
{
    int a=10;
    int b=20;
    std::cout<<b/a;
    return 0;
    //division
}*/
/*#include <iostream>
int main()
{
    int a=10;
    int b=20;
    std::cout<<b%a;
    return 0;
    //modules
}*/
/*#include <iostream>
int main()
{
    int num=99;
    ++num;//increment
    std::cout<<num;
    return 0;
}*/
#include <iostream>
int main()
{
    int num=101;
    --num;//decrement
    std::cout<<num;
    return 0;
}
























































