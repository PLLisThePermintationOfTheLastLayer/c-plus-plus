
/*#include <iostream>
using namespace std;
int main()
{
    for(int i=0; i<=100;i=i+2)
    {
     if(i==60)
     {
         continue;
     }
     cout<<i<<"\n";
    }
    return 0;
}*/
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    string names[3]={" Kyler"," Brian"," Raymond"};
    
    {for(int i=0;i<3;i++)
    cout<<i<<" "<<names[i]<<"\n";
    }
    return 0;
}*/
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    string names[6]={" " ," " ," " , " "," " ," " };
    for(int i=0;i<6;i++)
    {
    cout<<i<<" "<<names[i]<<"\n";
    }
    return 0;
}*/
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    string names[3]={" Kyler"," Brian"," Raymond"};
    for(int i=0;i<3;i++)
    {
        names[2]=" e";
    cout<<i<<" "<<names[i]<<"\n";
    }
    return 0;
}*/
#include <iostream>
#include <string>
using namespace std;
int main()
{
    string names[2]={"Kyler","Brian"};
    int getArrayLength=sizeof(names)/sizeof(int);
    cout<<getArrayLength;
    return 0;
}

 

