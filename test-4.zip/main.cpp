/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/*#include <iostream>
using namespace std;
int main()
{
    int num=11;
    switch(num){
    
    case 1:
    cout<<"one";
    break;
     case 2:
    cout<<"two";
    break;
     case 3:
    cout<<"Three";
    break;
     case 4:
    cout<<"four";
    break;
     case 5:
    cout<<"five";
    break;
     case 6:
    cout<<"six";
    break;
     case 7:
    cout<<"seven";
    break;
     case 8:
    cout<<"eight";
    break;
     case 9:
    cout<<"nine";
    break;
     case 10:
    cout<<"ten";
    break;
    default:
    cout<<"nothing here";
    }
    return 0;
}*/
/*#include <iostream>
using namespace std;
int main()
{
    int i=-1;
    while(i>=-10){
        cout<<i<<"\n";
        i--;
    }
    return 0;
}*/
/*#include <iostream>
using namespace std;
int main()
{
    int i=1;
    while(i<=10){
        cout<<i<<"\n";
        i++;
    }
    return 0;
}*/
/*include <iostream>
using namespace std;
int main()
{
    int i=0;
    for(i=0;i<=40;i=i+2){
        cout<<i<<"\n";
    }
    return 0;
}*/
/*#include <iostream>
using namespace std;
int main()
{
    int i;
    int x;
    for(int i=1;i<=10;i++){
        cout<<i<<"\n";
        x=i+x;
    }
    cout<<"Your sum is:"<<x;
    return 0;
}*/
/*#include <iostream>
using namespace std;
int main()
{
    int primeNum=1;
    switch(primeNum){
        case 1:
        cout<<"one;
        break;"
        case 2:
        cout<<"two";
        break;
    }
}*/
#include <iostream>
using namespace std;
int main()
{
    for(int i=1;i<=2;i++)
    {
        cout<<"Outer:"<<i<<"\n";
        for j=1; j<=3;++j
    }
    {
        cout<<"Inner"
    }
    
}
















