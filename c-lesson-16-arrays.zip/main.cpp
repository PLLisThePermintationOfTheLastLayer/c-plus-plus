/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/*#include <iostream>
using namespace std;
int main()
{
 string letters[2][4]={
     {"A","B","C","D"},
     {"E","F","G","H"}
 };
 letters[0][0]="Z";
 letters[0][3]="M";
 cout<<letters[0][0]<<"\n";
 cout<<letters[0][3];
 return 0;
}*/
/*#include <iostream>
using namespace std;
int main()
{
     string letters[3][4]={
     {"A","B","C","D"},
     {"E","F","G","H"},
     {"I","J","K","L"}
 };
 for (int i=0;i<3;i++)
 for (int j=0;j<4;j++){
     cout<<letters[i][j]<<"\n";
 }
 return 0;
}*/
#include <iostream>
using namespace std;
int main()
{
     string letters[2][2][2]={
    {
    {"A","B"},
    {"C","D"}
     },
     {
            {"E","F"},
            {"G","H"}
        }
     
};
for (int i=0;i<2;i++)
{
for (int j=0;j<2;j++)
{
     for (int k=0;k<2;k++)
 {
     cout<<letters[i][j][k]<<"\n";
 }
 }
 }
 return 0;
}


