/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    struct{
        int num;
        string letters;
    }myStructure;
    myStructure.num=100;
    myStructure.letters="coding is decent";
    cout<<myStructure.num<<"\n";
    cout<<myStructure.letters;
    return 0;
}*/
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    struct{
        int num;
        string letters;
    }myStructure;
    myStructure.num=100;
    myStructure.letters="Ypu put the text:";
    myStructure.input;
    
    cout<<"put something below";
    cout<<myStructure.letters;
    return 0;
}*/
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
 struct{
        string brand;
        string model;
    }myCar1,myCar2;
   myCar1.brand="Audi";
     myCar1.model=" r8";
      myCar2.brand="Ford";
       myCar2.model=" 150";
       cout<<myCar1.brand<<myCar1.model<<"\n";
        cout<<myCar2.brand<<myCar2.model;
        return 0;
}*/
#include <iostream>
#include <string>
using namespace std;
int main()
{
    string game="Roblox";
    string videoGame=game;
    
    cout<<"Your reference example: "<<"\n";
    cout<<"-----------------------"<<"\n";
    cout<<game<<"\n";
    cout<<videoGame;
}





