/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    struct{
        int num;
        string myString;
    }myStructure;
    myStructure.num=100;
    myStructure.myString="iheasjdfnsjevindijdn kfod kovnjdohudjnhviojljfbvhkjndudncuhvjndksunascivnsdjk";
    cout<<myStructure.num<<"\n";
    cout<<myStructure.myString;
}*/
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    struct{
        string fruit1;
        string fruit2;
        string fruit3;
    }myStructure;
    myStructure.fruit1="orange, orange";
    myStructure.fruit2="banana, yellow";
    myStructure.fruit2="lemon , yellow";
    cout<<myStructure.fruit1<<"\n";
    cout<<myStructure.fruit2<<"\n";
    cout<<myStructure.fruit3;
}*/
/*#include <iostream>
using namespace std;
void homework(){
    cout<<"I WILL NOT DO MY HOMEWORK"<<"\t";
}
int main(){
    for(int i=1;1<=100;i++){
        homework();
    }
}*/
/*#include <iostream>
#include <string>
using namespace std;
void name(string lname=" Tsui")
{
    cout<<name<<lname<<"Tsui"<<"\n";
}
int main()
{
    name("Kyler ");
}*/
#include <iostream>
#include <string>
using namespace std;
void flower(string flower="Sun flower:")
{
    cout<<flower<<"\n";
}
int main()
{
    flower();
    flower("yellow");
}



























