/*#include <iostream>//q1
#include <string>
using namespace std;
int main()
{
    string x;
    cout<<"Enter your words:";
    getline(cin,x);
    cout<<x;
}*/
/*#include <iostream>//q2
using namespace std;
int main()
{
    int x=10;
    int y=12;
    cout<<"and:"<<(x<y&&x>y)<<"\n";
    cout<<"or:"<<(x<y||x>y);
}*/
/*#include <iostream>//q3
#include <string>
int main()
{
    std::string x="kind";
    x[0]='w';
    std::cout<<x;
    return 0;
}*/
/*#include <iostream>//q4
#include <cmath>
using namespace std;
int main()
{
    cout<<log(9)<<"\n"<<sqrt(84);
}*/
/*#include <iostream>//q5
using namespace std;
int main()
{
    int x;
    cout<<"Enter your number";
    cin>>x;
    if(0<x){
    cout<<"Your number is:"<<x;
    }
    else{
        cout<<"It is skipped";
    }
}*/
/*#include <iostream>//q6
using namespace std;
int main()
{
    int x=10;
    int y=12;
    if(x<y){
    cout<<"I am learning if-else conditional statements";
    }
    else{
        cout<<"U are wrong";
    }
}*/
/*#include <iostream>//q7
using namespace std;
int main()
{
    int x=10;
    int y=12;
    if(x<y){
        cout<<"idk what u ment by test the values";
    }
}*/
/*#include <iostream>//q8
using namespace std;
int main()
{
    int x=5;
    int y=10;
    if(x<y){
        cout<<"its just an example";
    }
    else if(x==y){
        cout<<"Its another example";
    }
    else{
        cout<<"still another example";
    }
}*/
/*#include <iostream>//q9
using namespace std;
int main()
{
    int months=14;
    switch (months)
    {
        case 1:
        cout<<"January";
        break;
        case 2:
        cout<<"Febuary";
        break;
        case 3:
        cout<<"March";
        break;
        case 4:
        cout<<"April";
        break;
        case 5:
        cout<<"May";
        break;
        case 6:
        cout<<"June";
        break;
        case 7:
        cout<<"July";
        break;
        case 8:
        cout<<"August";
        break;
        case 9:
        cout<<"September";
        break;
        case 10:
        cout<<"October";
        break;
        case 11:
        cout<<"November";
        break;
        case 12:
        cout<<"December";
        break;
        default:
        cout<<"This is not a month";
        //no break
    }
}*/
/*#include <iostream>//q10
using namespace std;
int main()
{
   int x=1;
   while(x<=10){
       cout<<x<<"\n";
     x++;
   }
   return 0;
}*/
/*#include <iostream>//q11
using namespace std;
int main()
{
    int i;
    cout<<"ENter your number";
    do{
        cout<<"Do the math yourself";
        cout<<"1+2+3+4+5+6+7+8+9+10:"<<i<<"\n";
        i++;
    }
    while(i<=95);
    return 0;
}*/
/*#include <iostream>//q12
using namespace std;
int main()
{
    for(int n=1;n<=100;n=n+2)
    {
        cout<<n<<"\n";
    }
    return 0;
}*/
/*#include <iostream>//q13
using namespace std;
int main()
{
    for(int n=1;n<=5;n++)
    {
        cout<<"Assignment Day"<<"\n";
    }
    return 0;
}*/
/*#include <iostream>//14
using namespace std;
int main()
{
    int sum;
    for(int i=1;i<=10;i++)
    {
        cout<<i<<"\n";
        sum=i+sum;
    }
    cout<<"Your sum is:"<<sum;
}*/
/*#include <iostream>//q15
using namespace std;
int main()
{
    for(int n=1;n<=64;n=n*2)
    {
        cout<<n<<"\n";
    }
    return 0;
}*/
/*#include <iostream>//q16
using namespace std;
int main()
{
    int i,j,rows;
    cout<<"input number of rows";
    cin>>rows;
    for(i=1;i<=rows;i++)
    {
        for(j=1;j<=i;j++)
        cout<<"+";
        cout<<endl;
    }
    return 0;
}*/

























