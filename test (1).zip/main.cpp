/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

**************************************************************************/
/*#include <iostream>
int main()
{
    int myAge=11;
    std::cout<<"i am "<<myAge<<" years old.";
    return 0;
}*/
/*#include <iostream>
int main()
{
    int xXx=11;
    std::cout<<"i am"<<"\n"<<xXx<<"\n"<<"years old";
    return 0;
}*/
/*#include <iostream>
int main()
{
    int myNum=50;
    std::cout<<myNum;
    return 0;
}*/
/*#include <iostream>
#include <string>
int main()
{
   std::string text="Goodbye";// add std before string
    std::cout<<text;
    return 0;
}*/
/*#include <iostream>
int main()
{
    int numOne=1;
    int numTwo=2;
    std::cout<<numOne+numTwo;
    return 0;
}*/
/*#include <iostream>
int main()
{
    int numOne=10;
    int numTwo=2;
    std::cout<<numOne*numTwo;
    return 0;
}*/
/*#include <iostream>
int main()
{
int nuM=3;
int nUm=3;
int nUmm=3;
std::cout<<nuM<<"\n"<<nUm<<"\n"<<nUmm;
return 0;
}*/
/*#include <iostream>
int main()
{
char euro='E';  
char dollor='$';
std::cout<<euro;
std::cout<<dollor;
return 0;
}*/
/*#include <iostream>
int main()
{
    int x,y,z;
    x=y=z=1;
    std::cout<<x<<"\n"<<y<<"\n"<<z;
    return 0;
    
}*/
/*#include <iostream>
int main()
{
    int month=30;
    int year=365;
    int leap_Year=366;
    std::cout<<month<<"\n"<<year<<"\n"<<leap_Year;
    return 0;
}*/
/*#include <iostream>
int main()
{
    const int x=12;
    x=13
    std::cout<<x;
    return 0;
}*/
/*#include <iostream>
int main()
{
    char sience='A';
    char math='A';
    char reading='a';
    std::cout<<sience<<math<<reading;
    return 0;
}*/
/*#include <iostream>
int main()
{
    bool yay=true;
    bool nay=false;
    std::cout<<yay<<"\n"<<nay;
    return 0;
}*/
#include <iostream>
int main()
{
 int x=98,y=78,z=100;
 std::cout<<x<<"\n"<<y<<"\n"<<z;
 return 0;
}






















































































































