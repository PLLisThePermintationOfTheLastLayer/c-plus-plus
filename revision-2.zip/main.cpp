/*#include <iostream>
#include <string>
using namespace std;
int main()
{
     string names[3]={"Kyler\n","Brian\n","Raymond"};
     cout<<names[2];
}*/
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    for(int i=0;i<3;i++){
      string names[3]={"Kyler\n","Brian\n","Raymond"};
      cout<<names[i];
    }
}*/
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
     string names[3]={"Kyler\n","Brian\n","Raymond"};
     names[2]="NO MORE RAYMOND";
     cout<<names[2];
}*/
/*#include <iostream>
using namespace std;
int main()
{
    int number[3]={1,2,3};
    cout<<sizeof(number);
}*/
/*#include <iostream>
using namespace std;
int main()
{
    int number[3]={1,2,3};
    for(int i=0; i<sizeof(number)/sizeof(int); i++){
        cout<<number[i]<<"\n";
    }
}*/
/*#include <iostream>
using namespace std;
int main()
{
    string letters[2][4] = {
    {"A","B","C","D"},
    {"E","F","G","H"}
};
cout<<letters[0][3];
}*/
#include <iostream>
using namespace std;
int main(){
        string letters[2][2][2]= {
            {
                {"A","B"},
                {"C","D"}
            },
            {
                {"E","F"},
                {"G","H"}
            }
    };
    for(int i=0; i<2;i++){
    for(int j=0;j<2;j++){
    for(int k=0;k<2;k++){
        cout<<letters[i][j][k]<<"\n";
    }
    }
    }
}


















