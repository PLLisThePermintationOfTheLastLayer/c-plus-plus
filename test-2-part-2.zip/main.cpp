/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/*#include <iostream>
int main()
{
    int x=1;
    int y=0;
    std::cout<<(x<y&&x>y)<<"\n";//0
    std::cout<<(x<y||x>y)<<"\n";//1
    std::cout<<(!(x<y&&x>y))<<"\n";//1
    return 0;
}*/
/*#include <iostream>
int main()
{
    int x;
    int y;
    std::cout<<"Enter your number ";
    std::cin>>x;
    std::cout<<"Enter your number ";
    std::cin>>y;
    int sum=x+y;
    int difference=x-y;
    int product=x*y;
    int quotient=x/y;
    int mod=x%y;
    std::cout<<x<<" + "<<y<<" = "<<sum<<"\n";
    std::cout<<x<<" - "<<y<<" = "<<difference<<"\n";
    std::cout<<x<<" * "<<y<<" = "<<product<<"\n";
    std::cout<<x<<" / "<<y<<" = "<<quotient<<"\n";
    std::cout<<x<<" % "<<y<<" = "<<mod<<"\n";
    return 0;
}*/
/*#include <iostream>
int main ()
{
    double dollorUS=1.33;
    int dollorCanadien=1;
    std::cout<<dollorCanadien<< " canadien dollor is equal to "<<dollorUS<< " US dollors.";
    return 0;
}*/
/*#include <iostream>
int main()
{
    char num1=89;
    char num2=100;
    char num3=112;
    std::cout<<num1<<"\n"<<num2<<"\n"<<num3<<"\n";
    return 0;
}*/
#include <iostream>
#include <string>
int main()
{
    std::string x="operators";
    std::cout<<"Hello everyone!"<<"\n";
    std::cout<<"Today is my second test topics for the test are all datatypes and "<<x;
    return 0;
}




















































