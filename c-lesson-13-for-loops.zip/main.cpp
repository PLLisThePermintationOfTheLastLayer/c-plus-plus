/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/*#include <iostream>
int main()
{
    int num,product=5;
    do{
        std::cout<<"Enter a number"<<"\n";
        std::cin>>num;
        product*=num;
    }
    while(num!=1);
        std::cout<<"Product is "<<product;
        return 0;
}*/
/*#include <iostream>
int main()
{
    double num,quotient=5;
    do{
        std::cout<<"Enter a number"<<"\n";
        std::cin>>num;
        quotient/=num;
    }
    while(num!=1);
        std::cout<<" Your quotient is "<<quotient;
        return 0;
}*/
/*#include <iostream>
using namespace std;
int main()
{
    int i=1;
    do{
        cout<<i<<"\n";
        i++;
    }
    while(i<45);
}*/
/*#include <iostream>
using namespace std;
int main()
{
    for (int i=1;i<=21 ;i=i+2)
    {
        cout<<i<<"\n";
    }
    return 0;
}*/
/*#include <iostream>
using namespace std;
int main()
{
    for(int n=1;n<=5;n++)
    {
        cout<<"yes"<<"\n";
    }
    return 0;
}*/
#include <iostream>
using namespace std;
int main()
{
   int sum=0;
   int num;
  for(int num=1;num<=10;num++)
  sum=sum+num;
      cout<<"Enter Your number";
      cin>>num;
  cout<<"your sum is "<<sum;
  return 0;
}















