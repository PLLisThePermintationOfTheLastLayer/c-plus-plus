/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/*#include <iostream>//q1
using namespace std;
int main()
{
   cout<<"This is sentence 1"<<"\n";
   cout<<"This is sentence 2";
}*/
/*#include <iostream>//q2
using namespace std;
int main()
{
    int x,y,z=0;
    cout<<x<<y<<z;
}*/
/*#include <iostream>//q3
using namespace std;
int main()
{
    int leapYearDays=366;
    cout<<leapYearDays;
}*/
/*#include <iostream>//q4
using namespace std;
int main()
{
   string euro="€";
   char x='E';
   cout<<euro<<"\n"<<x;
}*/
/*#include <iostream>//q5
using namespace std;
int main()
{
     bool on=1;
     bool off=0;
     cout<<"ON:"<<on<<"\n"<<"OFF:"<<off;
}*/
/*#include <iostream>//q6
using namespace std;
int main()
{
    char x='A';
    cout<<x;
}*/
/*#include <iostream>//q8
#include <string>
using namespace std;
int main()
{
    double x=2.22;
    float y=3.3f;
    string z="Hi";
    cout<<x<<"\n"<<y<<"\n"<<z;
}*/
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    string countryVariable="U.S";
    cout<<countryVariable;
}*/
/*#include <iostream>//q9
using namespace std;
int main()
{
    int x;
     cout<<"How many minutes are there in 5 hours?";
     cin>>x;
     if(x==300){
         cout<<"correct, There are 300 mins in 5 hours";
     }
     else{
         cout<<"just admit it, your wrong";
     }
}*/
/*#include <iostream>//q10
#include <string>
using namespace std;
int main()
{
    string x;
    int y;
    cout<<"What is your favorite subject?";
    cin>>x;
    cout<<"WHat is your grade in that subject?";
    cin>>y;
    cout<<"Your favorite subject:"<<x<<"\n"<<"Your grade in that subject:"<<y;
}*/
/*#include <iostream>//q11
int main()
{
    int x,y;
    double z;
    int sub;
    int mul;
    double div;
    int sum;
    std::cout<<"Type your first number:";
    std::cin>>x;
    std::cout<<"Type your second number:";
    std::cin>>y;
    std::cout<<"Type your third number:";
    std::cin>>z;
    mul=x*y*z;
    sub=x-y-z;
    div=x/y/z;
    sum=x+y+z;
    std::cout<<"Your difference is:"<<sub<<"\n";
    std::cout<<"Your product is:"<<mul<<"\n";
    std::cout<<"Your sum is:"<<sum<<"\n";
    std::cout<<"Your quotient is:"<<div<<"\n";
    return 0;
}*/
/*#include <iostream>//q12
#include <string>
using namespace std;
int main()
{
    string x;
    cout<<"Enter your sentence:";
    getline(cin,x);
    cout<<x;
}*/
/*#include <iostream>//q13
#include <string>
using namespace std;
int main()
{
    string x="Kyler ";
    string i="Kyler ";
    string z="Tsui";
    x.append(z);
    cout<<x<<"\n"<<i+z;
}*/
/*#include <iostream>//q14
#include <string>
using namespace std;
int main()
{
    string x="uygygygygygygggygygy";
    cout<<x.length();
}*/
/*#include <iostream>
#include <cmath>
int main()
{
    int x=50;
    int y=10;
    std::cout<<"max:"<<std::max(x,y)<<"\n";
    std::cout<<"min:"<< std::min(x,y);
    return 0;
}*/




















