/*#include <iostream>
#include <string>
using namespace std;
void myfunction(string country="U.S")
{
    cout<<country<<"\n";
}
int main()
{
    myfunction("Canada");
    myfunction("U.K");
    myfunction("Germany");
    myfunction();
}*/
#include <iostream>
using namespace std;
void myFunction(double A=5.5)
{
    cout<<A<<"\n";
}
int main()
{
    myFunction(5.4);
     myFunction(5);
      myFunction(5.46);
       myFunction(6);
        myFunction();
}
