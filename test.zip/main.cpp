/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    int y;
   string x="example";
   y=x.size();
   cout<<"The size of example is:"<<y;
   

    return 0;
}*/
/*#include <iostream>
using namespace std;
int main()
{
    int x=100;
    int y=30;
    cout<<"The maximum of 100 and 30 is: "<<max(x,y)<<"\n";
     cout<<"The minimum of 100 and 30 is: "<<min(x,y)<<"\n";
     return 0;
}*/
/*#include <iostream>
using namespace std;
int main()
{
    int x=100;
    int y=30;
    cout<<(x>y)<<"\n";
    cout<<(x<y)<<"\n";
     cout<<(x==y)<<"\n";
      cout<<(x<=y)<<"\n";
       cout<<(x>=y)<<"\n";
        cout<<(x!=y)<<"\n";
        return 0;
}*/
/*#include <iostream>
#include <string>
int main()
{
    std::string x;
    std::cout<<"Type your full name";
    getline(std::cin,x);
    std::cout<<" My full name is "<<x;
    return 0;
}*/
/*#include <iostream>
using namespace std;
int main()
{
int x=100;
int y=30;
cout<<(x<y&&x>y)<<"\n";
cout<<(x<y||x>y)<<"\n";
return 0;
}*/
/*#include <iostream>
#include <string>
int main()
{
    std::string x="hello";
    x[0]='M';
    std::cout<<x;
    return 0;
}*/
/*#include <iostream>
#include <cmath>
using namespace std;
int main()
{
    int x=99;
    int y=6;
    cout<<log(y)<<"\n";
    cout<<sqrt(x);
    return 0;
}*/
/*#include <iostream>
using namespace std;
int main()
{
    int x;
    cout<<"The temperture is:";
    cin>>x;
    if(x=10)
    {
        cout<<"Go party";
    }
    else if(x=30)
    {
        cout<<"Stay home and play games";
    }
    else if(x=35)
    {
        cout<<"Go swiming";
    }
    else if(x>=20)
    {
        cout<<"go for a picnic";
    }
    return 0;
}*/
#include <iostream>
using namespace std;
int main()
{
    int x;
    cout<<"Enter your number:";
    cin>>x;
    if(x<0){
        cout<<"not this";
    }
    else{
    cout<<"Your number is: "<<x;
    }
    return 0;
}















