/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/*#include <iostream>
using namespace std;
int main()
{
int vowels=6;
switch(vowels){
    case 1:
    cout<<"a";
    break;
    case 2:
    cout<<"e";
    break;
    case 3:
    cout<<"i";
    break;
    case 4:
    cout<<"o";
    break;
    case 5:
    cout<<"u";
    break;
    default:
    cout<<"No vowels here";
}*/
/*#include <iostream>
using namespace std;
int main()
{
    int senses=1;
    switch(senses){
        case 1:
        cout<<"touch";
        break;
        case 2:
        cout<<"smell";
        break;
        case 3:
        cout<<"hearing";
        break;
        case 4:
        cout<<"taste";
        break;
        case 5:
        cout<<"vision";
        break;
        default:
        cout<<"NO senses here";
    }
    return 0;
}*/
/*#include <iostream>
using namespace std;
int main()
{
    int x=0;
    while(1<5){
        cout<<x<<"\n";
        x++;
    }
    return 0;
}*/
/*#include <iostream>
using namespace std;
int main()
{
   int x=0;
   while(x<96){
       cout<<x<<"\n";
     x++;
   }
   return 0;
}*/
/*#include <iostream>
using namespace std;
int main()
{
    int n=1;
    while(n<=5){
        cout<<"Hello world"<<"\n";
        n++;
    }
    return 0;
}*/
/*include <iostream>
using namespace std;
int main()
{
    int i=1;
    do{
        cout<<i<<"\tea";
        i++;
    }
    while(i<=95);
    return 0;
}*/
#include <iostream>
using namespace std;
int main()
{
    int num;
    int sum;
    cout<<"Enter a number";
    cin>>num;
    while(num>=0){
        sum+=num;
        cout<<"Enter another number";
        cin>>num;
    }
    cout<<"The sum is: "<<sum;
    return 0;
}






























