/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/*#include <iostream>
using namespace std;
int main()
{
    string name="Kyler ";
    string lastName="Tsui \n";
    string fullName=name+lastName;
    cout<<fullName;
    cout<<name.append(lastName);
    
}*/
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    string bigWord="xscipjko[ pvu9cfuic 9giecfu9evjwcdu9c- wegycdu9gykcu92vhkxciuhk";
    cout<<"The size of the string "<<bigWord.size()<<" characters";
}*/
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    string word="access";
    string wordTwo="Nice";
    cout<<word[0]<<"\n";
    wordTwo[0]='M';
    cout<<wordTwo;
}*/
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    string x;
    cout<<" Enter your words:";
    getline(cin,x);
    cout<<x;
}*/
/*#include <iostream>
using namespace std;
int main()
{
    int x=24;
    int y=24;
    if(x<y){
        cout<<"Hello World";
    }
    else if(x>y){
        cout<<"Goodbye World";
    }
    else{
        cout<<"hi world";
    }
}*/
/*#include <iostream>
using namespace std;
int main()
{
    int Time=3;
    switch (Time)
    {
        case 1:
        cout<<"9:00 is c++/python";
        break;
        case 2:
        cout<<"5:00 is HTML/Javascript";
        break;
        default:
        cout<<"YAY, NO CLASS";
    }  
}*/
/*#include <iostream>
using namespace std;
int main()
{
    int i=1;
    while (i<=7){
        cout<<"Simon says HELLO"<<"\n";
        i++;
    }
}*/
/*#include <iostream>
using namespace std;
int main()
{
    int i=1;
    do{
        cout<<i<<"\n";
        i++;
    }
    while(i<=5);
}*/
/*#include <iostream>
using namespace std;
int main()
{
    int rows=6;
    for(int i=1;i<=rows;i++)
    {
        for(int j=1;j<=rows;j++)
        cout<<"+";
        cout<<endl;
    }
}*/
#include <iostream>
using namespace std;
int main()
{
    for(int i=1; i<=5; i++){
        if(i==3){
            continue;
        }
        cout<<i<<endl;
    }
}


















