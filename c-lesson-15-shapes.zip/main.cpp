/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/*#include <iostream>
using namespace std;
int main()
{
    int i,j,rows;
    cout<<"\n\n display the pattern like the right ange triangle using an asterisk:\n";
    cout<<"----------------------------------------------------------------------\n";
    cout<<"input number of rows";
    cin>>rows;
    for(i=1;i<=rows;i++)
    {
        for(j=1;j<=i;j++)
        cout<<"+";
        cout<<endl;
    }
    return 0;
}*/
/*#include <iostream>
using namespace std;
int main()
{
    int size;
    cout<<"Input number or characters:";
    cin>>size;
    for(int row=1;row<=size;++row)
    {
        for(int col=1;col<=size;++col)
        {
            cout<<"()";
        }
        cout<<endl;
    }
    return 0;
}*/
/*#include <iostream>
using namespace std;
int main()
{
   int i,n,sum=0;
   cout<< "\n\n Find the sum or (1*1)+(2-2)+(3*3)+(4*4)+(5*5)+...+(n*n:\n)";
   cout<<"input values";
   cin>>n;
   for(i=1;i<=n;i++)
   {
       sum+=i*i;
       cout<<i<<"*"<<i<<"="<<i*i<<endl;
   }
   cout<<"The sum:"<<sum<<endl;
}*/
#include <iostream>
using namespace std;
int main()
{
    int j,i,n;
    cout<<"Input the number up to 5: ";
    cin>>n;
    cout<<"multiplication table 1 to "<<n<<endl;
    for(i=1;i<=12;i++)
    {
        for(j=1;j<=n;j++)
        {
        if(j<=n-1)
        cout<<j<<" x "<<i<<" = "<<i*j<<"\t";
        else
        cout<<j<<" x "<<i<<" = "<<i*j;
        }
        cout<<endl;
        }
}







