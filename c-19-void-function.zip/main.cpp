/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/*#include <iostream>
using namespace std;
void my()
{
    cout<<"HI";
}
int main()
{
    my();
     my();
    return 0;
}*/
/*#include <iostream>
using namespace std;
void homework()
{
    cout<<"I WILL NOT DO MY HOMEWORK"<<"\n";
}
int main()
{
    homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
     homework();
    return 0;
}*/
#include <iostream>
using namespace std;
void homework()
{
    cout<<"I WILL NOT DO MY HOMEWORK"<<"\t";
}
int main()
{
    for(int i=1;1<=100;i++){
    homework();
}
}







